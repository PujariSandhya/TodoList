import React, {Component} from 'react'


class Create extends Component
{
	constructor(props) {
		super(props);
		
		this.state = {
			
			description  : '',
			
		}
		
		this.baseState = this.state
		
		this.handleInsertUser = this.handleInsertUser.bind(this);
		this.handleInputFieldChange = this.handleInputFieldChange.bind(this);
	}
	//--- Update state variable value while input field change ---//
	handleInputFieldChange(e) {
		this.setState({
			[e.target.name] : e.target.value
		})
	}
	//--- Insert new user in users state array by props method ---//
	handleInsertUser(e) {
		e.preventDefault()
		const data = {
			id 		  : Math.floor(Math.random() * 100),
			description  : this.state.description,
			
		}
		if( !this.checkValidation(data) ) {
			this.reset();
			this.props.updateState(data, 0);
			// document.getElementById("closeAddModal").click();
			
		}
	}
	//--- Validate all input field ---//
    checkValidation(fields) {
    	var error = {};
    	if(fields.description.length === 0) {
    		error.description = ['This field is required!'];
    	}
    	
		if(fields.description.length === 0 ) {
			return true;
		} else {
			return false;
		}
    }
    //--- Reset all state variable while insert new user ---//
    reset() {
        this.setState(this.baseState);
    }
   

    render() {
      return(
		
			<div className='container'>

			        <form onSubmit={this.handleInsertUser}>
			      		<div className="modal-body">
			          		<div className="form-group" style={{width:"500px"}}>
			            		<label htmlFor="description" className="col-form-label">Adding The Text</label>
			            		<input type="text" className={`form-control form-control-sm `}
			            		 id="description" name="description" placeholder="enter text here" onChange={this.handleInputFieldChange} value={this.state.description}/>
			            		<br/><button type="submit" className="btn btn-primary btn-sm" >ADD</button>
			         	 	</div>
			          		
			      		</div>
			      		{/* <div className="modal-footer">
			        	
			        		<button type="submit" className="btn btn-primary btn-sm" >ADD TEXT</button>
			      		</div> */}
			   		</form>
					
					   </div>
		
        )
	  }
}
export default Create