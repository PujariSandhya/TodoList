import React, {Component} from 'react'


class Edit extends Component
{
	constructor(props) {
		super(props);
		//--- Declare method for this component ---//
		this.state = {
			
			user_id   : '',
			description  : '',
			
		}
		//--- Declare method for this component ---//
		this.baseState = this.state
		
		this.handleUpdateUser = this.handleUpdateUser.bind(this);
		this.handleInputFieldChange = this.handleInputFieldChange.bind(this);
	}
	//--- Receive props while update modal open ---//
	componentWillReceiveProps(user_data) {
		this.setState({
			user_id   : user_data.user.id,
			description  : user_data.user.description,
			
		})
	}
	//--- Update state variable value while input field change ---//
	handleInputFieldChange(e) {
		this.setState({
			[e.target.name] : e.target.value
		})
	}
	//--- Update state users variable by props method ---//
	handleUpdateUser(e) {
		e.preventDefault()
		//--- Declare state variable for this component ---//
		const data = {
			id        : this.state.user_id,
			description  : this.state.description,
			
		}
		if( !this.checkValidation(data) ) {
			this.reset();
			this.props.updateState(data, 1);
			document.getElementById("closeEditModal").click();
			
		}
	}
    //--- Validate all input field ---//
    checkValidation(fields) {
    	var error = {};
    	if(fields.description.length === 0) {
    		error.description = ['This field is required!'];
    	}
    	
		if(fields.description.length === 0 ) {
			return true;
		} else {
			return false;
		}
    }
    //--- Reset all state variable while update user ---//
	reset() {
        this.setState(this.baseState);
    }
   

    render() {
      return(
			<div className="modal fade" id="editModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  	<div className="modal-dialog" role="document">
			    	<div className="modal-content">
			      		<div className="modal-header">
			        		<h5 className="modal-title">Edit the Text</h5>
			        		<button type="button" className="close" data-dismiss="modal" aria-label="Close">
			          			<span aria-hidden="true">&times;</span>
			        		</button>
			      		</div>
			        <form onSubmit={this.handleUpdateUser}>
			      		<div className="modal-body">
			          		<div className="form-group">
			            		<label htmlFor="description" className="col-form-label">Edit Text:</label>
			            		<input type="text" className={`form-control form-control-sm `}
			            		 id="description" name="description" placeholder="enter inpput" onChange={this.handleInputFieldChange} value={this.state.description}/>
			            	
			         	 	</div>
			          		
			      		</div>
			      		<div className="modal-footer">
			        		<button type="button" id="closeEditModal" className="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
			        		<button type="submit" className="btn btn-primary btn-sm">Save</button>
			      		</div>
			   		</form>
			    	</div>
			  	</div>
				
			</div>
        )
    }
}
export default Edit